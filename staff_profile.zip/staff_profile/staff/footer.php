<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">


<footer class="footer">
    <div class="footer-left">
        <p>&copy; 2025 Dr. I. Carol | 
            <a href="mailto:carolcrl23@example.com"><i class="bi bi-envelope-fill"></i> carolcrl23@example.com</a> | 
            <a href="tel:+1234567890"><i class="bi bi-telephone-fill"></i> 8870078584</a>
        </p>
    </div>
    <div class="footer-right">
        <a href="https://facebook.com" target="_blank" class="social-link"><i class="bi bi-facebook"></i></a>
        <a href="https://instagram.com" target="_blank" class="social-link"><i class="bi bi-instagram"></i></a>
        <a href="https://linkedin.com" target="_blank" class="social-link"><i class="bi bi-linkedin"></i></a>
    </div>
</footer>

</body>
</html>
